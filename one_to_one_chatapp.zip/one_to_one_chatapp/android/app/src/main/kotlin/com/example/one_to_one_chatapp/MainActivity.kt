package com.example.one_to_one_chatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
